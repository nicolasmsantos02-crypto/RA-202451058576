import Saudacao from "./components/saudacao";
import CartaoPerfil from "./components/CartaoPerfil";

function App() {
  const nome = "Carlos";
  const ano = 2026;
  return (
    <>
      <h1 className="titulo">Olá, {nome}!</h1>
      <h1>Olá, {nome}</h1>
      <p>Em {ano + 1} eu já vou saber React.</p>
      <p>Seu nome gritado: {nome.toUpperCase()}</p>
      <Saudacao nome="Bruno" />
      <Saudacao nome="Ana" />
      <Saudacao nome="João" />
      <Saudacao />
      <CartaoPerfil nome="Ana" curso="ADS" emoji="🎸" />
      <CartaoPerfil nome="Bruno" curso="SI" emoji="⚽" />
      <CartaoPerfil nome="Carla" curso="CC" emoji="🎮" />


    </>
  );
}
export default App; 
