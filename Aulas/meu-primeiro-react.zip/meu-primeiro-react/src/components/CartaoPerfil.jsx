function CartaoPerfil(props) {
    return (
        <div className="cartao">
            <h2>{props.nome}</h2>
            <p>Curso: {props.curso}</p>
            <p>Emoji: {props.emoji}</p>
        </div>
    );
}

export default CartaoPerfil;


